Steps to run the project,
1) Create and start the containers in background,
   docker-compose up --build -d
2) Check the status of the container processes
   docker-compose ps
   This should display two containers one for mysql_db service and other for python_app service
3) Connect to mysql database container to query the data from the output tables
   a. Launch the bash shell of the database container
	  docker-compose exec mysql_db bash
   b. Connect to the database through the mysql shell
	  #mysql -u root -p
	  Enter password: root
   c. Switch to the database "case_study"
      mysql> use case_study;
   d. Query the two tables to analyze the output,
	  mysql> select * from speed;
	  mysql> select * from activity;
4) Stop the container services
   docker-compose down
   
Note: Run time environment for this project needs docker installed along with docker-compose.
	  
   