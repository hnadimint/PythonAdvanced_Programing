import joblib
import pandas as pd
import numpy as np
import mysql.connector
from sklearn import preprocessing
from sqlalchemy import create_engine

def getDbConnection():
    db_username = 'root'
    db_password = 'root'
    db_ip       = 'mysql_db'
    dp_port     = '3306'
    db_name     = 'case_study'
    sqlEngine = create_engine('mysql+mysqlconnector://{0}:{1}@{2}:{3}/{4}'.
                                               format(db_username, db_password, 
                                                      db_ip, dp_port, db_name))
    return sqlEngine.connect()
	
def loadModel():
	joblib_file = "model.pkl"
	joblib_model = joblib.load(joblib_file)
	return joblib_model

# get the connection to MySQL database
db_conn = getDbConnection()
try:
    # load the raw data in csv
    df_raw = pd.read_csv("data_case_study.csv")

    # Impute the data. Set missing values to 0
    df_zero_imputed = df_raw.fillna(0)

    model_columns = ['timestamp','engine_speed','hydraulic_drive_off','drill_boom_in_anchor_position','pvalve_drill_forward','bolt','boom_long','boom_lati','drill_boom_long','drill_boom_lati','beam']

    # transform and scale the data
    df_tranformed_scaled = df_zero_imputed.assign(
        boom_long = preprocessing.scale(df_zero_imputed[['boom_lift','boom_lower']].mean(axis=1)),
        boom_lati = preprocessing.scale(df_zero_imputed[['boom_forward','boom_backward']].mean(axis=1)),
        drill_boom_long = preprocessing.scale(df_zero_imputed[['drill_boom_turn_left','drill_boom_turn_right']].mean(axis=1)),
        drill_boom_lati = preprocessing.scale(df_zero_imputed[['drill_boom_turn_forward','drill_boom_turn_backward']].mean(axis=1)),
        beam = preprocessing.scale(df_zero_imputed[['beam_left','beam_right']].mean(axis=1))
    )

    #select only the required columns for the model
    df_transformed = df_tranformed_scaled[model_columns]

    # invoke the predict method of the model to predict the activity type
    df_predicted = df_transformed.copy()
    df_predicted['type'] = loadModel().predict(df_predicted[model_columns[1:]])

    # Compute 5 minute average of 'engine_speed'
    df_predicted['dt'] = pd.to_datetime(df_predicted.timestamp,unit='s')
    df_avg_agg = df_predicted[['dt','engine_speed']].groupby(pd.Grouper(key='dt', freq='5min')).mean().dropna()

    # persist the aggregated results to 'speed' table in MySQL database
    df_avg_agg.to_sql(con=db_conn, name='speed', if_exists='replace')

    # collate the data to create activity periods
    df_collate = df_predicted[['dt','type']].sort_values(['dt'])
    df_collate['id'] = (df_collate['type'] != df_collate['type'].shift(1)).astype(int).cumsum()

    # aggregate the data to get duration of each activity
    df_final = df_collate.groupby(['id','type'],as_index=False).agg(start_time=('dt','min'),end_time=('dt','max'))
    df_final['duration'] = (df_final.end_time - df_final.start_time).dt.total_seconds()

    # persist the aggregated results to 'activity' table in MySQL database
    df_final[['start_time','end_time','duration','type']].to_sql(con=db_conn, name='activity', if_exists='replace',index=False)
except ValueError as vx:
    print(vx)
except Exception as ex:   
    print(ex)
finally:
    db_conn.close()
	
	